<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PricingType extends Model
{
    protected $fillable = [
        'name',
    ];
}
