@extends('template')

@section('content')
{!! Form::model($agencyPricing, ['method'=>'patch', 'action' => ['AgencyPricingController@update', $agencyPricing->id]]) !!}
<div class="panel panel-primary">
    <div class="panel-heading">
        <div class="row">
            <div class="col-md-6">
                <h3 class="panel-title" style="margin-top: 5px;">Update Agency Pricing</h3>
            </div>
            <div class="col-md-6">
                <div class="clearfix">
                    <a href="{{ action('AgencyPricingController@index') }}" class="btn btn-default btn-sm btn-quirk pull-right"><span class="glyphicon glyphicon-home"></span> Back to Index</a>

                    <a href="{{ action('AgencyPricingController@create') }}" class="btn btn-default btn-sm btn-quirk pull-right" style="margin-right: 10px;"><span class="glyphicon glyphicon-plus"></span> Create New Entry</a>
                </div>
            </div>            
        </div>
    </div>
    <div class="panel-body">
        <div class="row">
            <div class="col-md-9">
                <div class="form-group">
                    {!! Form::label('agency','Agency') !!}
                    {!! Form::select('agency_id',$agency,null,['class'=>'form-control select', 'id' => 'agency_id','placeholder'=>'PLEASE SELECT']) !!}
                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                    {!! Form::label('country','Country') !!}
                    {!! Form::select('country_id',$country,null,['class'=>'form-control select', 'id' => 'agency_id','placeholder'=>'PLEASE SELECT']) !!}
                </div>
            </div>
        </div>
        <div class="clearfix"></div>
        <div class="row" style="margin-top:20px;">
            <div class="col-md-4">
                <div class="form-group">
                    {!! Form::label('agency','Package') !!}
                    {!! Form::select('package_id',$package,null,['class'=>'form-control select', 'id' => 'agency_id','placeholder'=>'PLEASE SELECT']) !!}
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    {!! Form::label('pricing_type_id','Price Type') !!}
                    {!! Form::select('pricing_type_id',$pricingType,null,['class'=>'form-control select', 'id' => 'priceType','placeholder'=>'PLEASE SELECT']) !!}
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    {!! Form::label('price','Price') !!}
                    {!! Form::number('price',null,['class'=>'form-control', 'step'=>'0.01' , 'id' => 'price']) !!}
                </div>
            </div>
        </div>
    </div>
</div>    
<div class="row">
    <div class="col-md-3">
        <div class="form-group">
            {!! Form::button('<i class="glyphicon glyphicon-save"></i> SAVE ENTRY', array('type' => 'submit', 'class' => 'btn btn-primary btn-quirk')) !!}
        </div>
    </div>
</div> 
{!! Form::close() !!} 
@endsection