<div class="row">
	<div class="col-md-12">
		<a href="settings" class="btn btn-default">General Settings</a>
		<a href="settings?tab=vaccine" class="btn btn-default">Vaccine</a>
		<a href="settings?tab=user" class="btn btn-default">User Role</a>
	</div>
</div>