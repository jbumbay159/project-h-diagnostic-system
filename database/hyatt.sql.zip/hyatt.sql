-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 10, 2018 at 06:55 AM
-- Server version: 10.1.10-MariaDB
-- PHP Version: 7.0.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hyatt`
--

-- --------------------------------------------------------

--
-- Table structure for table `agencies`
--

CREATE TABLE `agencies` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact_person` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `agencies`
--

INSERT INTO `agencies` (`id`, `name`, `address`, `contact_person`, `created_at`, `updated_at`) VALUES
(1, 'MMML AGENCY', 'DAVAO CITY', 'SONNY KALAW', '2018-03-27 02:15:47', '2018-03-27 02:15:47'),
(2, 'SOPHIA AND NATASHA', 'DAVAO CITY', 'HUBERT FLORES', '2018-03-27 02:24:08', '2018-03-27 02:24:08'),
(3, 'A.KANAN MANPOWER AGENCY', 'DAVAO CITY', 'xxx', '2018-03-27 02:32:45', '2018-03-27 02:32:45'),
(4, 'SILVER SKILLED', 'DAVAO CITY', 'XXX', '2018-03-27 02:35:12', '2018-03-27 02:35:12'),
(5, 'JENERICK INTERNATIONAL MANPOWER', 'DAVAO CITY', 'xxx', '2018-03-27 02:40:19', '2018-03-27 02:40:19'),
(6, 'SKYWORLD', 'DAVAO CITY', 'xxx', '2018-03-27 02:42:01', '2018-03-27 02:42:01'),
(7, 'SKILLED MANAGEMENT', 'DAVAO CITY', 'xxx', '2018-03-27 02:48:42', '2018-03-27 02:48:42'),
(8, 'KING SOLOMON', 'DAVAO CITY', 'xxx', '2018-03-27 02:49:42', '2018-03-27 02:49:42'),
(9, 'BUSINESSWISE AGENCY', 'DAVAO CITY', 'xxx', '2018-03-27 02:51:45', '2018-03-27 02:51:45'),
(10, 'LGH AGENCY', 'DAVAO CITY', 'xxx', '2018-03-27 02:53:24', '2018-03-27 02:53:24'),
(11, 'LUZVIMIN', 'DAVAO CITY', 'xxx', '2018-03-27 02:56:04', '2018-03-27 02:56:04'),
(12, 'MECPREGO INTERNATIONAL', 'DAVAO CITY', 'xxx', '2018-03-27 02:57:26', '2018-03-27 02:57:26'),
(13, 'SAFE FUTURE AGENCY', 'DAVAO CITY', 'xxx', '2018-03-27 03:00:09', '2018-03-27 03:00:09'),
(14, 'MAX INTERNATIONAL AGENCY', 'DAVAO CITY', 'xxx', '2018-03-27 03:02:10', '2018-03-27 03:02:10'),
(15, 'CREATIVE', 'DAVAO CITY', 'xxx', '2018-03-27 03:07:40', '2018-03-27 03:07:40'),
(16, 'GBMLT GENSAN', 'DAVAO CITY', 'xxx', '2018-03-27 03:09:00', '2018-03-27 03:09:00'),
(17, 'GBMLT DAVAO', 'DAVAO CITY', 'xxx', '2018-03-27 03:09:41', '2018-03-27 03:09:41'),
(18, 'ADVANCE AGENCY', 'DAVAO CITY', 'xxx', '2018-03-27 03:27:55', '2018-03-27 03:27:55'),
(19, 'IEMPLOY3', 'DAVAO CITY', 'xxx', '2018-03-27 03:35:09', '2018-03-27 03:35:09'),
(20, 'IEMPLOY2', 'DAVAO CITY', 'xxx', '2018-03-27 03:37:31', '2018-03-27 03:37:31'),
(21, 'YHMD AGENCY', 'DAVAO CITY', 'xxx', '2018-03-27 03:41:28', '2018-03-27 03:41:28'),
(22, 'FOUR STAR', 'DAVAO CITY', 'xxx', '2018-03-27 03:47:27', '2018-03-27 03:47:27'),
(23, 'FOUR ACES', 'DAVAO CITY', 'xxx', '2018-03-27 03:53:59', '2018-03-27 03:53:59'),
(24, 'ALPHATOMO AGENCY', 'DAVAO CITY', 'xxx', '2018-03-27 03:58:12', '2018-03-27 03:58:12'),
(25, 'ALPHATOMO MAIN', 'DAVAO CITY', 'xxx', '2018-03-27 03:59:29', '2018-03-27 03:59:29'),
(26, 'EJM AGENCY', 'DAVAO CITY', 'XXX', '2018-03-27 03:59:48', '2018-03-27 03:59:48'),
(27, 'JIMC AGENCY', 'DAVAO CITY', 'xxx', '2018-03-27 04:01:51', '2018-03-27 04:01:51'),
(28, 'RAMASIA INTERNATIONL', 'DAVAO CITY', 'xxx', '2018-03-27 04:04:31', '2018-03-27 04:04:31'),
(29, 'HRHA AGECY', 'DAVAO CITY', 'xxx', '2018-03-27 04:06:09', '2018-03-27 04:06:09'),
(30, 'MYRIAD AGENCY', 'DAVAO CITY', 'xxx', '2018-03-27 04:08:24', '2018-03-27 04:08:24'),
(31, 'PHIL-Q MANPOWER', 'DAVAO CITY', 'xxx', '2018-03-27 04:09:13', '2018-03-27 04:09:13'),
(32, 'POEA', 'DAVAO CITY', 'XX', '2018-04-06 02:36:15', '2018-04-06 02:36:15');

-- --------------------------------------------------------

--
-- Table structure for table `agency_contacts`
--

CREATE TABLE `agency_contacts` (
  `id` int(10) UNSIGNED NOT NULL,
  `agency_id` int(10) UNSIGNED NOT NULL,
  `contact` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `agency_contacts`
--

INSERT INTO `agency_contacts` (`id`, `agency_id`, `contact`, `created_at`, `updated_at`) VALUES
(1, 4, 'xxx', '2018-03-27 02:35:12', '2018-03-27 02:35:12');

-- --------------------------------------------------------

--
-- Table structure for table `agency_customer`
--

CREATE TABLE `agency_customer` (
  `id` int(10) UNSIGNED NOT NULL,
  `customer_id` int(10) UNSIGNED NOT NULL,
  `agency_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `agency_customer`
--

INSERT INTO `agency_customer` (`id`, `customer_id`, `agency_id`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '2018-04-04 01:57:41', NULL),
(2, 2, 21, '2018-04-05 06:00:42', NULL),
(3, 3, 2, '2018-04-05 06:09:42', NULL),
(4, 4, 4, '2018-04-05 06:14:05', NULL),
(5, 5, 4, '2018-04-05 06:16:31', NULL),
(6, 6, 4, '2018-04-06 02:20:42', NULL),
(7, 7, 4, '2018-04-06 02:25:28', NULL),
(8, 8, 4, '2018-04-06 02:28:02', NULL),
(9, 9, 4, '2018-04-06 02:30:01', NULL),
(10, 10, 4, '2018-04-06 02:31:56', NULL),
(11, 11, 4, '2018-04-06 02:34:11', NULL),
(12, 12, 32, '2018-04-06 02:52:54', NULL),
(13, 13, 32, '2018-04-06 02:55:03', NULL),
(14, 14, 10, '2018-04-06 03:10:19', NULL),
(15, 15, 10, '2018-04-06 03:11:53', NULL),
(16, 16, 10, '2018-04-06 03:13:21', NULL),
(17, 17, 10, '2018-04-06 03:15:11', NULL),
(18, 18, 10, '2018-04-06 03:17:39', NULL),
(19, 19, 10, '2018-04-06 03:19:08', NULL),
(20, 20, 10, '2018-04-06 03:36:23', NULL),
(21, 21, 8, '2018-04-06 03:37:50', NULL),
(22, 22, 8, '2018-04-06 05:56:18', NULL),
(23, 23, 16, '2018-04-06 06:17:41', NULL),
(24, 24, 23, '2018-04-06 06:20:33', NULL),
(25, 25, 3, '2018-04-07 03:07:12', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `agency_emails`
--

CREATE TABLE `agency_emails` (
  `id` int(10) UNSIGNED NOT NULL,
  `agency_id` int(10) UNSIGNED NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `agency_emails`
--

INSERT INTO `agency_emails` (`id`, `agency_id`, `email`, `created_at`, `updated_at`) VALUES
(1, 1, 'mmmldavao@yahoo.com.ph', '2018-03-27 02:15:47', '2018-03-27 02:15:47'),
(2, 1, 'mmmldavaoqallaf@yahoo.com.ph', '2018-03-27 02:15:47', '2018-03-27 02:15:47'),
(3, 1, 'mmmldavao@gmail.com', '2018-03-27 02:15:47', '2018-03-27 02:15:47'),
(4, 1, 'divine.angel18.dcb@gmail.com', '2018-03-27 02:15:48', '2018-03-27 02:15:48'),
(5, 1, 'mipaniaveronica@yahoo.com.ph', '2018-03-27 02:15:48', '2018-03-27 02:15:48'),
(6, 2, 'sophiaandnatasha@yahoo.com', '2018-03-27 02:24:08', '2018-03-27 02:24:08'),
(7, 2, 'Hubertflores@yahoo.com', '2018-03-27 02:24:08', '2018-03-27 02:24:08'),
(9, 3, 'akananmanpower.corp@yahoo.com', '2018-03-27 02:33:04', '2018-03-27 02:33:04'),
(10, 4, 'silverskilled.davao@yahoo.com', '2018-03-27 02:35:12', '2018-03-27 02:35:12'),
(11, 5, 'jenerickbutuan@jenerick.com.ph', '2018-03-27 02:40:19', '2018-03-27 02:40:19'),
(12, 5, 'applicant.davao@jenerick.com.ph', '2018-03-27 02:40:20', '2018-03-27 02:40:20'),
(13, 6, 'skyworld_davao2017@yahoo.com', '2018-03-27 02:42:01', '2018-03-27 02:42:01'),
(14, 7, 'smc.jheiRan22@gmail.com', '2018-03-27 02:48:43', '2018-03-27 02:48:43'),
(15, 7, 'skilledjpc@yahoo.com', '2018-03-27 02:48:43', '2018-03-27 02:48:43'),
(16, 7, 'smc.cenverzo@yahoo.com', '2018-03-27 02:48:43', '2018-03-27 02:48:43'),
(17, 8, 'kingsolomon.davao@gmail.com', '2018-03-27 02:49:42', '2018-03-27 02:49:42'),
(18, 9, 'michellemok95@yahoo.com', '2018-03-27 02:51:45', '2018-03-27 02:51:45'),
(19, 10, 'lghinternationaldavao2015@gmail.com', '2018-03-27 02:53:24', '2018-03-27 02:53:24'),
(20, 11, 'luzvimintagumbranch@gmail.com', '2018-03-27 02:56:04', '2018-03-27 02:56:04'),
(21, 11, 'assej25@gmail.com', '2018-03-27 02:56:04', '2018-03-27 02:56:04'),
(22, 11, 'luzvimin.pagadian@gmail.com', '2018-03-27 02:56:04', '2018-03-27 02:56:04'),
(23, 11, 'lvm.iligan@gmail.com', '2018-03-27 02:56:04', '2018-03-27 02:56:04'),
(24, 12, 'acconts@mecprego.com', '2018-03-27 02:57:26', '2018-03-27 02:57:26'),
(25, 12, 'coordinator@mecprego.com', '2018-03-27 02:57:26', '2018-03-27 02:57:26'),
(26, 13, 'safefuture_davao2010@hotmail.com', '2018-03-27 03:00:10', '2018-03-27 03:00:10'),
(27, 14, 'davao.maxinternational@gmail.com', '2018-03-27 03:02:10', '2018-03-27 03:02:10'),
(28, 15, 'creative.artistservices@yahoo.com', '2018-03-27 03:07:40', '2018-03-27 03:07:40'),
(29, 15, 'pulmabrenda@yahoo.com', '2018-03-27 03:07:40', '2018-03-27 03:07:40'),
(30, 15, 'sheena_janne22@yahoo.com', '2018-03-27 03:07:40', '2018-03-27 03:07:40'),
(31, 15, 'haronoscar@yahoo.com', '2018-03-27 03:07:40', '2018-03-27 03:07:40'),
(32, 16, 'gensan@gbmlt.com.ph', '2018-03-27 03:09:00', '2018-03-27 03:09:00'),
(33, 17, 'davao@gbmlt.com.ph', '2018-03-27 03:09:41', '2018-03-27 03:09:41'),
(34, 18, 'asimsdavao@yahoo.com', '2018-03-27 03:27:55', '2018-03-27 03:27:55'),
(35, 18, 'asimsinc@yahoo.com', '2018-03-27 03:27:55', '2018-03-27 03:27:55'),
(36, 18, 'info@asims.com.ph', '2018-03-27 03:27:55', '2018-03-27 03:27:55'),
(37, 19, 'vanz051416@gmail.com', '2018-03-27 03:35:09', '2018-03-27 03:35:09'),
(38, 19, 'Iee.iemploy@gmail.com', '2018-03-27 03:35:09', '2018-03-27 03:35:09'),
(39, 19, 'angeli_jocson@yahoo.com', '2018-03-27 03:35:09', '2018-03-27 03:35:09'),
(40, 20, 'beautyjc2002@yahoo.com', '2018-03-27 03:37:31', '2018-03-27 03:37:31'),
(41, 20, 'primegoaldavao@gmail.com', '2018-03-27 03:37:31', '2018-03-27 03:37:31'),
(42, 21, 'yhmd.application@gmail.com', '2018-03-27 03:41:28', '2018-03-27 03:41:28'),
(43, 21, 'info@yhmd-manpower.com', '2018-03-27 03:41:28', '2018-03-27 03:41:28'),
(44, 21, 'yhmd.davao@yahoo.com', '2018-03-27 03:41:28', '2018-03-27 03:41:28'),
(45, 21, 'dian@yhmd-manpower.com', '2018-03-27 03:41:28', '2018-03-27 03:41:28'),
(46, 22, 'fscdavao@gmail.com', '2018-03-27 03:47:27', '2018-03-27 03:47:27'),
(47, 23, 'gogo.dvostaff@gmail.com', '2018-03-27 03:53:59', '2018-03-27 03:53:59'),
(48, 23, 'diplomatic_davao@hotmail.com', '2018-03-27 03:53:59', '2018-03-27 03:53:59'),
(49, 24, 'alphatomointernational@gmail.com', '2018-03-27 03:58:12', '2018-03-27 03:58:12'),
(50, 25, 'atp.davao2017@gmail.com', '2018-03-27 03:59:29', '2018-03-27 03:59:29'),
(52, 26, 'miaabdullah110892@gmail.com', '2018-03-27 04:01:15', '2018-03-27 04:01:15'),
(53, 26, 'marychriss.92@gmail.com', '2018-03-27 04:01:15', '2018-03-27 04:01:15'),
(54, 27, 'musazocra@gmail.com', '2018-03-27 04:01:51', '2018-03-27 04:01:51'),
(55, 28, 'lhalyn.arc.ual@gmail.com', '2018-03-27 04:04:31', '2018-03-27 04:04:31'),
(56, 29, 'hrhamedical_update@yahoo.com', '2018-03-27 04:06:09', '2018-03-27 04:06:09'),
(57, 29, 'nash.darwish.606@gmail.com', '2018-03-27 04:06:10', '2018-03-27 04:06:10'),
(58, 29, 'princenilong@yahoo.com', '2018-03-27 04:06:10', '2018-03-27 04:06:10'),
(59, 30, 'hsw@myriadphil.com', '2018-03-27 04:08:24', '2018-03-27 04:08:24'),
(60, 30, 'jobsdvo@myriad.com', '2018-03-27 04:08:25', '2018-03-27 04:08:25'),
(61, 31, 'hr@philqmanpower.com', '2018-03-27 04:09:13', '2018-03-27 04:09:13');

-- --------------------------------------------------------

--
-- Table structure for table `agency_pricings`
--

CREATE TABLE `agency_pricings` (
  `id` int(10) UNSIGNED NOT NULL,
  `package_id` int(10) UNSIGNED NOT NULL,
  `agency_id` int(10) UNSIGNED NOT NULL,
  `pricing_type_id` int(10) UNSIGNED NOT NULL,
  `price` decimal(15,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `country_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `agency_pricings`
--

INSERT INTO `agency_pricings` (`id`, `package_id`, `agency_id`, `pricing_type_id`, `price`, `created_at`, `updated_at`, `country_id`) VALUES
(1, 21, 1, 1, '2450.00', '2018-04-04 01:54:57', '2018-04-04 01:54:57', 2);

-- --------------------------------------------------------

--
-- Table structure for table `associations`
--

CREATE TABLE `associations` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `associations`
--

INSERT INTO `associations` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'DOH PACKAGE', '2018-04-04 01:49:08', '2018-04-04 01:49:08'),
(2, 'GAMCA PACKAGE', '2018-04-04 01:49:26', '2018-04-04 01:49:26');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'XRAY', '2018-03-26 08:29:05', '2018-03-26 08:29:05'),
(2, 'SEROLOGY', '2018-03-28 01:17:18', '2018-03-28 01:17:18'),
(3, 'CHEMISTRY', '2018-04-04 01:46:30', '2018-04-04 01:46:30'),
(4, 'HEMATOLOGY', '2018-04-04 01:46:40', '2018-04-04 01:46:40'),
(5, 'CLINICAL MICROSCOPY', '2018-04-04 01:47:03', '2018-04-04 01:47:03'),
(6, 'VACCINE', '2018-04-05 02:38:30', '2018-04-05 02:38:30'),
(7, 'ULTRASOUND', '2018-04-07 01:55:11', '2018-04-07 01:55:11'),
(8, 'ECG', '2018-04-07 02:02:50', '2018-04-07 02:02:50'),
(9, 'CONTAINER', '2018-04-07 02:17:38', '2018-04-07 02:17:38');

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE `countries` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `association_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`id`, `name`, `association_id`, `created_at`, `updated_at`) VALUES
(1, 'KUWAIT', 2, '2018-04-04 01:49:46', '2018-04-04 01:49:46'),
(2, 'SAUDI', 2, '2018-04-04 01:49:54', '2018-04-04 01:49:54'),
(3, 'QATAR', 2, '2018-04-04 01:50:02', '2018-04-04 01:50:02'),
(4, 'JAPAN', 1, '2018-04-04 01:50:12', '2018-04-04 01:50:12'),
(5, 'SOUTH KOREA', 1, '2018-04-04 01:50:24', '2018-04-04 01:50:24'),
(6, 'AUSTRALIA', 1, '2018-04-04 01:50:39', '2018-04-05 02:40:25'),
(7, 'BAHRAIN', 2, '2018-04-04 01:51:01', '2018-04-04 01:51:01');

-- --------------------------------------------------------

--
-- Table structure for table `country_customer`
--

CREATE TABLE `country_customer` (
  `id` int(10) UNSIGNED NOT NULL,
  `customer_id` int(10) UNSIGNED NOT NULL,
  `country_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `country_customer`
--

INSERT INTO `country_customer` (`id`, `customer_id`, `country_id`, `created_at`, `updated_at`) VALUES
(1, 1, 2, '2018-04-04 01:57:41', NULL),
(2, 2, 2, '2018-04-05 06:00:42', NULL),
(3, 3, 3, '2018-04-05 06:09:42', NULL),
(4, 4, 3, '2018-04-05 06:14:05', NULL),
(5, 5, 3, '2018-04-05 06:16:31', NULL),
(6, 6, 3, '2018-04-06 02:20:42', NULL),
(7, 7, 3, '2018-04-06 02:25:28', NULL),
(8, 8, 3, '2018-04-06 02:28:02', NULL),
(9, 9, 3, '2018-04-06 02:30:01', NULL),
(10, 10, 3, '2018-04-06 02:31:56', NULL),
(11, 11, 3, '2018-04-06 02:34:11', NULL),
(12, 12, 4, '2018-04-06 02:52:54', NULL),
(13, 13, 6, '2018-04-06 02:55:03', NULL),
(14, 14, 2, '2018-04-06 03:10:18', NULL),
(15, 15, 2, '2018-04-06 03:11:53', NULL),
(16, 16, 2, '2018-04-06 03:13:21', NULL),
(17, 17, 2, '2018-04-06 03:15:11', NULL),
(18, 18, 2, '2018-04-06 03:17:39', NULL),
(19, 19, 2, '2018-04-06 03:19:08', NULL),
(20, 20, 3, '2018-04-06 03:36:23', NULL),
(21, 21, 2, '2018-04-06 03:37:50', NULL),
(22, 22, 2, '2018-04-06 05:56:18', NULL),
(23, 23, 2, '2018-04-06 06:17:41', NULL),
(24, 24, 3, '2018-04-06 06:20:33', NULL),
(25, 25, 2, '2018-04-07 03:07:12', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(10) UNSIGNED NOT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `middle_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name_extension` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `birthdate` date NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remarks` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` longtext COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `barcode` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `last_name`, `first_name`, `middle_name`, `name_extension`, `gender`, `birthdate`, `address`, `contact_number`, `remarks`, `photo`, `created_at`, `updated_at`, `barcode`) VALUES
(1, 'RODRIGO', 'CHARLENE MAE', 'ALBRANDO', NULL, 'FEMALE', '1991-05-18', 'DAVAO CITY', '09999999', 'PASSPORT', 'dcbyJFWfCy.jpg', '2018-04-04 01:57:41', '2018-04-04 01:57:57', '20180404157191'),
(2, 'BUTALID', 'JOLIBEE', 'PEPITO', NULL, 'FEMALE', '1994-08-03', 'DAVAO CITY', '090000', 'NO ID PRESENTED', NULL, '2018-04-05 06:00:42', '2018-04-05 06:00:42', '20180405532790'),
(3, 'AMBAN', 'VICKY', 'SALDO', NULL, 'FEMALE', '1981-10-09', 'DAVAO CITY', '000', 'VOTERS ID', NULL, '2018-04-05 06:09:42', '2018-04-05 06:09:42', '20180405679695'),
(4, 'SEPE', 'BEVERLYN', 'SEVERINO', NULL, 'FEMALE', '1994-12-03', 'DAVAO CITY', '0000', 'COMPANY ID', NULL, '2018-04-05 06:14:05', '2018-04-05 06:14:05', '20180405759318'),
(5, 'CAYENA', 'MERRY CLAIRE', 'LIM', NULL, 'FEMALE', '1978-04-22', 'DAVAO CITY', '00', 'PHILHEALTH ID', NULL, '2018-04-05 06:16:31', '2018-04-05 06:16:31', '20180405477959'),
(6, 'PRADILLA', 'EMIE LOU', 'FLOJO', NULL, 'FEMALE', '1987-07-15', 'DAVAO CITY', '00', 'VOTERS ID', NULL, '2018-04-06 02:20:42', '2018-04-06 02:20:42', '20180406891434'),
(7, 'PURISIMA', 'ANA MARIE', 'BARGAMENTO', NULL, 'FEMALE', '1993-05-29', 'DAVAO CITY', '00', 'PHILHEALTH', NULL, '2018-04-06 02:25:28', '2018-04-06 02:25:28', '20180406243123'),
(8, 'JIMENEZ', 'ABIGAEL', 'ALFEREZ', NULL, 'FEMALE', '1995-05-16', 'DAVAO CITY', '00', 'COMPANY ID', NULL, '2018-04-06 02:28:02', '2018-04-06 02:28:02', '20180406305525'),
(9, 'QUINTO', 'JULIET', 'RAMOS', NULL, 'FEMALE', '1985-07-27', 'DAVAO CITY', '00', 'PASSPORT', NULL, '2018-04-06 02:30:01', '2018-04-06 02:30:01', '20180406378829'),
(10, 'CRESCENCIO', 'MARITES', 'MUUTAS', NULL, 'FEMALE', '1977-05-02', 'DAVAO CITY', '0', 'PASSPORT', NULL, '2018-04-06 02:31:56', '2018-04-06 02:31:56', '20180406992557'),
(11, 'RELLANOS', 'JOSSIECA', 'AVILA', NULL, 'FEMALE', '1995-04-27', 'DAVAO CITY', '00', 'BIRTH CERT.', NULL, '2018-04-06 02:34:11', '2018-04-06 02:34:11', '20180406766851'),
(12, 'ILAO', 'WILSON JOHN', 'LAROBES', NULL, 'MALE', '1984-06-10', 'DAVAO CITY', '00', 'PASSPORT', NULL, '2018-04-06 02:52:54', '2018-04-06 02:52:54', '20180406299819'),
(13, 'LOYOLA', 'PRETTY JOY', 'BUENO', NULL, 'FEMALE', '1987-07-21', 'DAVAO CITY', '00', 'PASSPORT', NULL, '2018-04-06 02:55:03', '2018-04-06 02:55:03', '20180406534416'),
(14, 'ALIM', 'LIZA MAE', 'DANDA', NULL, 'FEMALE', '1993-05-28', 'DAVAO CITY', '00', 'NBI', NULL, '2018-04-06 03:10:18', '2018-04-06 03:10:18', '20180406593091'),
(15, 'LUMAMBAS', 'HANNAH', 'UROD', NULL, 'FEMALE', '1989-12-19', 'DAVAO CITY', '00', 'PASSPORT', NULL, '2018-04-06 03:11:53', '2018-04-06 03:11:53', '20180406539525'),
(16, 'ALINA', 'AIDA', 'CAGADAS', NULL, 'FEMALE', '1983-02-24', 'DAVAO CITY', '00', 'NBI CLEARANCE', NULL, '2018-04-06 03:13:21', '2018-04-06 03:13:21', '20180406598989'),
(17, 'LASTIMOSA', 'PRECILA', 'VALLENTE', NULL, 'FEMALE', '1982-01-16', 'DAVAO CITY', '00', 'NBI CLEARANCE', NULL, '2018-04-06 03:15:11', '2018-04-06 03:15:11', '20180406257270'),
(18, 'MAMANGKAS', 'ERIKA', 'DIOCOLANO', NULL, 'FEMALE', '1994-12-02', 'DAVAO CITY', '00', 'NBI CLEARANCE', NULL, '2018-04-06 03:17:39', '2018-04-06 03:17:39', '20180406109964'),
(19, 'DIMALEN', 'NARIBAI', 'SACANDAL', NULL, 'FEMALE', '1990-06-30', 'DAVAO CITY', '00', 'PASSPORT', NULL, '2018-04-06 03:19:08', '2018-04-06 03:19:08', '20180406200124'),
(20, 'AMBAG', 'ASNIYA', 'ABPI', NULL, 'FEMALE', '1990-09-20', 'DAVAO CITY', '00', 'PASSPORT', NULL, '2018-04-06 03:36:23', '2018-04-06 03:36:23', '20180406475899'),
(21, 'YANA', 'ALONA MAE', 'GARDE', NULL, 'FEMALE', '1991-05-09', 'DAVAO CITY', '00', 'VOTERS ID', NULL, '2018-04-06 03:37:50', '2018-04-06 03:37:50', '20180406467626'),
(22, 'ROA', 'AMYPHIR', 'MANALO', NULL, 'FEMALE', '1982-10-07', 'DAVAO CITY', '00', 'PASSPORT', NULL, '2018-04-06 05:56:18', '2018-04-06 05:56:18', '20180406213400'),
(23, 'VELASCO', 'ARVIE', 'DUHAYLUNGSOD', NULL, 'FEMALE', '1989-07-24', 'DAVAO CITY', '00', 'PASSPORT', NULL, '2018-04-06 06:17:41', '2018-04-06 06:17:41', '20180406686398'),
(24, 'TABARA', 'BADRIA', 'UYAG', NULL, 'FEMALE', '1992-04-24', 'DAVAO CITY', '00', 'PASSPORT', NULL, '2018-04-06 06:20:33', '2018-04-06 06:20:33', '20180406714914'),
(25, 'PARAISO', 'BERNADETH', 'PAMA', NULL, 'FEMALE', '1993-08-23', 'DAVAO CITY', '00', 'VOTERS CERT.', NULL, '2018-04-07 03:07:12', '2018-04-07 03:07:12', '20180407837055');

-- --------------------------------------------------------

--
-- Table structure for table `fingerprints`
--

CREATE TABLE `fingerprints` (
  `id` int(10) UNSIGNED NOT NULL,
  `customer_id` int(10) UNSIGNED NOT NULL,
  `finger` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `templates` blob NOT NULL,
  `hash` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `inventory_lab_result_items`
--

CREATE TABLE `inventory_lab_result_items` (
  `id` int(10) UNSIGNED NOT NULL,
  `customer_id` int(10) UNSIGNED NOT NULL,
  `sale_id` int(10) UNSIGNED NOT NULL,
  `lab_result_id` int(10) UNSIGNED NOT NULL,
  `supply_id` int(10) UNSIGNED NOT NULL,
  `testqty` int(11) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `inventory_receives`
--

CREATE TABLE `inventory_receives` (
  `id` int(10) UNSIGNED NOT NULL,
  `date_received` date NOT NULL,
  `remarks` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `inventory_receive_items`
--

CREATE TABLE `inventory_receive_items` (
  `id` int(10) UNSIGNED NOT NULL,
  `inventory_receive_id` int(10) UNSIGNED NOT NULL,
  `supply_id` int(10) UNSIGNED NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT '0',
  `lot_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_expired` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `price` decimal(11,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `inventory_returns`
--

CREATE TABLE `inventory_returns` (
  `id` int(10) UNSIGNED NOT NULL,
  `date_return` date NOT NULL,
  `remarks` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `inventory_return_items`
--

CREATE TABLE `inventory_return_items` (
  `id` int(10) UNSIGNED NOT NULL,
  `inventory_return_id` int(10) UNSIGNED NOT NULL,
  `supply_id` int(10) UNSIGNED NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT '0',
  `lot_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_expired` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `remarks` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lab_results`
--

CREATE TABLE `lab_results` (
  `id` int(10) UNSIGNED NOT NULL,
  `customer_id` int(10) UNSIGNED NOT NULL,
  `sale_id` int(10) UNSIGNED NOT NULL,
  `service_id` int(10) UNSIGNED NOT NULL,
  `category_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remarks` text COLLATE utf8mb4_unicode_ci,
  `interpret` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `file_no` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_done` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lab_results`
--

INSERT INTO `lab_results` (`id`, `customer_id`, `sale_id`, `service_id`, `category_name`, `name`, `remarks`, `interpret`, `created_at`, `updated_at`, `file_no`, `is_done`) VALUES
(1, 1, 1, 1, 'XRAY', 'XRAY: PA', NULL, NULL, '2018-04-04 01:57:41', '2018-04-04 01:57:41', NULL, 0),
(2, 2, 2, 41, 'VACCINE', 'VACCINE', NULL, NULL, '2018-04-05 06:00:42', '2018-04-05 06:00:42', NULL, 0),
(3, 3, 3, 41, 'VACCINE', 'VACCINE', NULL, NULL, '2018-04-05 06:09:42', '2018-04-05 06:09:42', NULL, 0),
(4, 4, 4, 1, 'XRAY', 'XRAY: PA', NULL, NULL, '2018-04-05 06:14:05', '2018-04-05 06:14:05', NULL, 0),
(5, 5, 5, 1, 'XRAY', 'XRAY: PA', NULL, NULL, '2018-04-05 06:16:31', '2018-04-05 06:16:31', NULL, 0),
(6, 6, 6, 1, 'XRAY', 'XRAY: PA', NULL, NULL, '2018-04-06 02:20:42', '2018-04-06 02:20:42', NULL, 0),
(7, 7, 7, 1, 'XRAY', 'XRAY: PA', NULL, NULL, '2018-04-06 02:25:28', '2018-04-06 02:25:28', NULL, 0),
(8, 8, 8, 1, 'XRAY', 'XRAY: PA', NULL, NULL, '2018-04-06 02:28:03', '2018-04-06 02:28:03', NULL, 0),
(9, 9, 9, 41, 'VACCINE', 'VACCINE', NULL, NULL, '2018-04-06 02:30:01', '2018-04-06 02:30:01', NULL, 0),
(10, 10, 10, 1, 'XRAY', 'XRAY: PA', NULL, NULL, '2018-04-06 02:31:56', '2018-04-06 02:31:56', NULL, 0),
(11, 11, 11, 1, 'XRAY', 'XRAY: PA', NULL, NULL, '2018-04-06 02:34:11', '2018-04-06 02:34:11', NULL, 0),
(12, 12, 12, 1, 'XRAY', 'XRAY: PA', NULL, NULL, '2018-04-06 02:52:54', '2018-04-06 02:52:54', NULL, 0),
(13, 13, 13, 1, 'XRAY', 'XRAY: PA', NULL, NULL, '2018-04-06 02:55:03', '2018-04-06 02:55:03', NULL, 0),
(14, 14, 14, 1, 'XRAY', 'XRAY: PA', NULL, NULL, '2018-04-06 03:10:19', '2018-04-06 03:10:19', NULL, 0),
(15, 15, 15, 1, 'XRAY', 'XRAY: PA', NULL, NULL, '2018-04-06 03:11:53', '2018-04-06 03:11:53', NULL, 0),
(16, 16, 16, 41, 'VACCINE', 'VACCINE', NULL, NULL, '2018-04-06 03:13:21', '2018-04-06 03:13:21', NULL, 0),
(17, 17, 17, 41, 'VACCINE', 'VACCINE', NULL, NULL, '2018-04-06 03:15:11', '2018-04-06 03:15:11', NULL, 0),
(18, 18, 18, 1, 'XRAY', 'XRAY: PA', NULL, NULL, '2018-04-06 03:17:39', '2018-04-06 03:17:39', NULL, 0),
(19, 19, 19, 1, 'XRAY', 'XRAY: PA', NULL, NULL, '2018-04-06 03:19:08', '2018-04-06 03:19:08', NULL, 0),
(20, 20, 20, 1, 'XRAY', 'XRAY: PA', NULL, NULL, '2018-04-06 03:36:23', '2018-04-06 03:36:23', NULL, 0),
(21, 21, 21, 1, 'XRAY', 'XRAY: PA', NULL, NULL, '2018-04-06 03:37:50', '2018-04-06 03:37:50', NULL, 0),
(22, 22, 22, 41, 'VACCINE', 'VACCINE', NULL, NULL, '2018-04-06 05:56:19', '2018-04-06 05:56:19', NULL, 0),
(23, 23, 23, 41, 'VACCINE', 'VACCINE', NULL, NULL, '2018-04-06 06:17:41', '2018-04-06 06:17:41', NULL, 0),
(24, 24, 24, 41, 'VACCINE', 'VACCINE', NULL, NULL, '2018-04-06 06:20:33', '2018-04-06 06:20:33', NULL, 0),
(25, 25, 25, 1, 'XRAY', 'XRAY: PA', NULL, NULL, '2018-04-07 03:07:12', '2018-04-07 03:07:12', NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `lab_result_items`
--

CREATE TABLE `lab_result_items` (
  `id` int(10) UNSIGNED NOT NULL,
  `lab_result_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `group` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `normal_values` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `co_values` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `result` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remarks` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2017_12_02_025256_create_roles_table', 1),
(4, '2017_12_02_025823_create_role_user_table', 1),
(5, '2017_12_02_032632_create_associations_table', 1),
(6, '2017_12_02_033029_create_countries_table', 1),
(7, '2017_12_02_041447_create_agencies_table', 1),
(8, '2017_12_02_051652_create_categories_table', 1),
(9, '2017_12_02_053730_create_services_table', 1),
(10, '2017_12_02_055910_create_service_items_table', 1),
(11, '2017_12_02_104632_create_packages_table', 1),
(12, '2017_12_02_112406_package_service', 1),
(13, '2017_12_02_132351_create_customers_table', 1),
(14, '2017_12_03_011644_create_pricing_types_table', 1),
(15, '2017_12_03_043541_create_customer_country_table', 1),
(16, '2017_12_03_045538_create_sales_table', 1),
(17, '2017_12_03_050208_create_agency_pricings_table', 1),
(18, '2017_12_04_080639_create_agency_customer_table', 1),
(19, '2017_12_05_032416_create_payments_table', 1),
(20, '2017_12_05_062051_create_lab_results_table', 1),
(21, '2017_12_05_081656_create_lab_result_items_table', 1),
(22, '2017_12_06_035113_create_transmittals_table', 1),
(23, '2017_12_07_033957_create_fingerprints_table', 1),
(24, '2017_12_29_030830_create_agency_emails_table', 2),
(25, '2017_12_29_035259_create_agency_contacts_table', 2),
(26, '2017_12_29_152302_create_country_id_table', 3),
(27, '2018_01_02_111626_add_days_table_in_sales', 3),
(28, '2018_01_02_192318_create_req_transactions_table', 3),
(29, '2018_01_16_143849_create_barcode_id_in_customer_table', 4),
(30, '2018_01_17_155651_create_trans_id_column', 5),
(31, '2018_01_17_183658_drop_column_in_transmittal', 6),
(32, '2018_01_18_144627_create_service_prices_table', 7),
(33, '2018_02_06_143303_create_supplies_table', 8),
(34, '2018_02_13_160844_create_inventory_receives_table', 9),
(35, '2018_02_13_165656_create_inventory_returns_table', 9),
(36, '2018_02_14_142802_create_inventory_receive_items_table', 10),
(37, '2018_02_15_142140_create_xray_column_service', 11),
(38, '2018_02_16_130846_create_service_supplies_table', 12),
(39, '2018_02_16_145806_create_inventory_lab_result_items_table', 13),
(40, '2018_02_17_145719_create_inventory_return_items_table', 14),
(41, '2018_02_26_141451_create_settings_table', 15),
(42, '2018_02_27_143039_create_vaccines_table', 16),
(43, '2018_03_10_120627_create_sale_discounts_table', 17),
(44, '2018_03_11_153555_add_column_users_table', 18),
(46, '2018_03_11_162143_create_xray_results_table', 19),
(47, '2018_03_24_143207_add_column_service_item_table', 20);

-- --------------------------------------------------------

--
-- Table structure for table `packages`
--

CREATE TABLE `packages` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` decimal(15,2) NOT NULL,
  `days` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `packages`
--

INSERT INTO `packages` (`id`, `name`, `price`, `days`, `created_at`, `updated_at`) VALUES
(1, 'FULL MED:SOPHIA AND NATASHA', '3500.00', 30, '2018-03-26 08:33:02', '2018-03-28 01:52:30'),
(2, 'FULL MED:LUXURY', '2700.00', 30, '2018-03-28 01:38:09', '2018-03-28 01:38:09'),
(3, 'FULL MED:HIMARK', '2700.00', 30, '2018-03-28 01:39:26', '2018-03-28 01:39:26'),
(4, 'FULL MED:AROUND THE WORLD', '3000.00', 30, '2018-03-28 01:40:08', '2018-03-28 01:52:21'),
(5, 'FULL MED:SKYLINE MANPOWER SOLUTION INC', '3500.00', 30, '2018-03-28 01:42:09', '2018-03-28 01:42:09'),
(6, 'FULL MED:2 I-EMPLOY', '2500.00', 30, '2018-03-28 01:51:14', '2018-03-28 01:51:14'),
(7, 'FULL MED:BUSINESSWISE', '2800.00', 30, '2018-03-28 01:52:03', '2018-03-28 01:52:03'),
(8, 'FULL MED:PHIL-Q AGENCY', '3500.00', 30, '2018-03-28 01:53:13', '2018-03-28 01:53:13'),
(9, 'FULL MED:FOUR STAR CORP', '2800.00', 30, '2018-03-28 01:53:50', '2018-03-28 01:53:50'),
(10, 'FULL MED:YHMD AGENCY', '2500.00', 30, '2018-03-28 01:54:14', '2018-03-28 01:54:14'),
(11, 'FULL MED:JIMC AGENCY', '3200.00', 30, '2018-03-28 01:54:40', '2018-03-28 01:54:40'),
(12, 'FULL MED:MAX INTERNATIONAL AGENCY', '2800.00', 30, '2018-03-28 01:55:14', '2018-03-28 01:55:14'),
(13, 'FULL MED:2 ALPHA TOMO MAIN', '3500.00', 30, '2018-03-28 01:55:52', '2018-03-28 01:55:52'),
(14, 'FULL MED:MYRIAD AGENCY', '3000.00', 30, '2018-03-28 02:21:23', '2018-03-28 02:21:23'),
(15, 'FULL MED:3 IEMPLOY', '2500.00', 30, '2018-03-28 02:21:55', '2018-03-28 02:21:55'),
(16, 'FULL MED:SKYWORLD', '2800.00', 30, '2018-03-28 02:23:16', '2018-03-28 02:23:16'),
(17, 'FULL MED:PRIME GOAL', '3500.00', 30, '2018-03-28 02:23:46', '2018-03-28 02:23:46'),
(18, 'FULL MED:SKILLED MANAGEMENT', '3000.00', 30, '2018-03-28 02:24:13', '2018-03-28 02:24:13'),
(19, 'FULL MED:CREATIVE', '3000.00', 30, '2018-03-28 02:24:54', '2018-03-28 02:24:54'),
(20, 'FULL MED:A.KANAN/BADILLA', '2200.00', 30, '2018-03-28 02:25:39', '2018-03-28 02:25:39'),
(21, 'FULL MED:MMML AGENCY', '3000.00', 30, '2018-03-28 02:26:15', '2018-03-28 02:26:15'),
(22, 'FULL MED:SAFE FUTURE', '3500.00', 30, '2018-03-28 02:27:02', '2018-03-28 02:27:02'),
(23, 'FULL MED:ADVANCE', '2900.00', 30, '2018-03-28 02:50:02', '2018-03-28 02:50:02'),
(24, 'FULL MED:ALPHA TOMO', '3200.00', 30, '2018-03-28 02:56:02', '2018-03-28 02:56:02'),
(25, 'FULL MED:EJM AGENCY', '2500.00', 30, '2018-03-28 02:56:30', '2018-03-28 02:56:30'),
(26, 'FULL MED:FOUR ACES', '2200.00', 30, '2018-03-28 02:56:54', '2018-03-28 02:56:54'),
(27, 'FULL MED:GBMLT AGENCY', '2700.00', 30, '2018-03-28 02:57:26', '2018-03-28 02:57:26'),
(28, 'FULL MED:HRHA', '3000.00', 30, '2018-03-28 02:58:55', '2018-03-28 02:58:55'),
(29, 'FULL MED:JENERICK AGENCY', '2900.00', 30, '2018-03-28 03:00:28', '2018-03-28 03:00:28'),
(30, 'FULL MED:KING SOLOMON', '2800.00', 30, '2018-03-28 03:00:47', '2018-03-28 03:00:47'),
(31, 'FULL MED:LGH AGENCY', '2200.00', 30, '2018-03-28 03:01:20', '2018-03-28 03:01:20'),
(32, 'FULL MED:LUZVIMIN', '3000.00', 30, '2018-03-28 03:01:48', '2018-03-28 03:01:48'),
(33, 'FULL MED:MECPREGO', '3000.00', 30, '2018-03-28 03:02:10', '2018-03-28 03:02:10'),
(34, 'FULL MED:RAMASIA AGENCY', '2800.00', 30, '2018-03-28 03:02:55', '2018-03-28 03:02:55'),
(35, 'FULL MED:SILVER SKILLED', '3000.00', 30, '2018-03-28 03:03:23', '2018-03-28 03:03:23'),
(36, 'PHASE 1 DOH PACKAGE', '2200.00', 30, '2018-03-28 03:10:18', '2018-03-28 03:10:18'),
(37, 'PRE-MED WITH PREGNANCY TEST', '720.00', 10, '2018-03-28 03:13:31', '2018-03-28 03:13:31'),
(38, 'VACCINE', '1200.00', 10, '2018-04-05 05:48:41', '2018-04-05 05:48:41'),
(39, 'PRE-MED', '750.00', 10, '2018-04-05 06:12:23', '2018-04-05 06:12:23'),
(40, 'GAMCA PACKAGE TEST', '3500.00', 30, '2018-04-07 02:12:05', '2018-04-07 02:12:05'),
(41, 'CHEMISTRY PANEL', '920.00', 1, '2018-04-07 02:13:03', '2018-04-07 02:13:03'),
(42, 'RE-MEDICAL PACKAGE', '2000.00', 10, '2018-04-07 02:15:28', '2018-04-07 02:15:28'),
(43, 'HEALTH CARD', '280.00', 10, '2018-04-07 02:16:15', '2018-04-07 02:16:15'),
(44, 'COMPREHENSIVE TEST', '1500.00', 10, '2018-04-07 03:01:52', '2018-04-07 03:01:52');

-- --------------------------------------------------------

--
-- Table structure for table `package_service`
--

CREATE TABLE `package_service` (
  `id` int(10) UNSIGNED NOT NULL,
  `package_id` int(10) UNSIGNED NOT NULL,
  `service_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `package_service`
--

INSERT INTO `package_service` (`id`, `package_id`, `service_id`, `created_at`, `updated_at`) VALUES
(1, 1, 1, NULL, NULL),
(2, 2, 1, NULL, NULL),
(3, 3, 1, NULL, NULL),
(4, 4, 1, NULL, NULL),
(5, 5, 1, NULL, NULL),
(6, 6, 1, NULL, NULL),
(7, 7, 1, NULL, NULL),
(8, 8, 1, NULL, NULL),
(9, 9, 1, NULL, NULL),
(10, 10, 1, NULL, NULL),
(11, 11, 1, NULL, NULL),
(12, 12, 1, NULL, NULL),
(13, 13, 1, NULL, NULL),
(14, 14, 1, NULL, NULL),
(15, 15, 1, NULL, NULL),
(16, 16, 1, NULL, NULL),
(17, 17, 1, NULL, NULL),
(18, 18, 1, NULL, NULL),
(19, 19, 1, NULL, NULL),
(20, 20, 1, NULL, NULL),
(21, 21, 1, NULL, NULL),
(22, 22, 1, NULL, NULL),
(23, 23, 1, NULL, NULL),
(24, 24, 1, NULL, NULL),
(25, 25, 1, NULL, NULL),
(26, 26, 1, NULL, NULL),
(27, 27, 1, NULL, NULL),
(28, 28, 1, NULL, NULL),
(29, 29, 1, NULL, NULL),
(30, 30, 1, NULL, NULL),
(31, 31, 1, NULL, NULL),
(32, 32, 1, NULL, NULL),
(33, 33, 1, NULL, NULL),
(34, 34, 1, NULL, NULL),
(35, 35, 1, NULL, NULL),
(36, 36, 1, NULL, NULL),
(37, 37, 1, NULL, NULL),
(38, 38, 41, NULL, NULL),
(39, 39, 1, NULL, NULL),
(40, 40, 1, NULL, NULL),
(41, 41, 9, NULL, NULL),
(42, 42, 1, NULL, NULL),
(43, 43, 1, NULL, NULL),
(44, 44, 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(10) UNSIGNED NOT NULL,
  `sale_id` int(10) UNSIGNED NOT NULL,
  `customer_id` int(10) UNSIGNED NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `payment_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `sale_id`, `customer_id`, `amount`, `payment_id`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '2450.00', 2, '2018-04-04 01:58:54', '2018-04-04 01:58:54'),
(2, 2, 2, '1200.00', 2, '2018-04-05 06:01:18', '2018-04-05 06:01:18'),
(3, 3, 3, '1200.00', 2, '2018-04-05 06:10:11', '2018-04-05 06:10:11'),
(4, 4, 4, '750.00', 2, '2018-04-05 06:14:38', '2018-04-05 06:14:38'),
(5, 5, 5, '750.00', 2, '2018-04-05 06:17:08', '2018-04-05 06:17:08'),
(6, 6, 6, '750.00', 2, '2018-04-06 02:21:32', '2018-04-06 02:21:32'),
(7, 7, 7, '750.00', 2, '2018-04-06 02:26:21', '2018-04-06 02:26:21'),
(8, 8, 8, '750.00', 2, '2018-04-06 02:28:26', '2018-04-06 02:28:26'),
(9, 9, 9, '1200.00', 2, '2018-04-06 02:30:21', '2018-04-06 02:30:21'),
(10, 10, 10, '750.00', 2, '2018-04-06 02:32:35', '2018-04-06 02:32:35'),
(11, 11, 11, '750.00', 2, '2018-04-06 02:34:42', '2018-04-06 02:34:42'),
(12, 12, 12, '2200.00', 1, '2018-04-06 02:53:15', '2018-04-06 02:53:15'),
(13, 13, 13, '2200.00', 1, '2018-04-06 02:55:19', '2018-04-06 02:55:19'),
(14, 14, 14, '2200.00', 2, '2018-04-06 03:10:35', '2018-04-06 03:10:35'),
(15, 15, 15, '2200.00', 2, '2018-04-06 03:12:11', '2018-04-06 03:12:11'),
(16, 16, 16, '1200.00', 2, '2018-04-06 03:13:56', '2018-04-06 03:13:56'),
(17, 17, 17, '1200.00', 2, '2018-04-06 03:15:43', '2018-04-06 03:15:43'),
(18, 18, 18, '2200.00', 2, '2018-04-06 03:18:02', '2018-04-06 03:18:02'),
(19, 19, 19, '2200.00', 2, '2018-04-06 03:19:25', '2018-04-06 03:19:25'),
(20, 20, 20, '2200.00', 2, '2018-04-06 03:36:42', '2018-04-06 03:36:42'),
(21, 21, 21, '2800.00', 2, '2018-04-06 03:38:09', '2018-04-06 03:38:09'),
(22, 22, 22, '1200.00', 2, '2018-04-06 05:56:49', '2018-04-06 05:56:49'),
(23, 23, 23, '1200.00', 2, '2018-04-06 06:18:26', '2018-04-06 06:18:26'),
(24, 24, 24, '1200.00', 2, '2018-04-06 06:20:57', '2018-04-06 06:20:57'),
(25, 25, 25, '1500.00', 2, '2018-04-07 03:07:50', '2018-04-07 03:07:50');

-- --------------------------------------------------------

--
-- Table structure for table `pricing_types`
--

CREATE TABLE `pricing_types` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pricing_types`
--

INSERT INTO `pricing_types` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'DISCOUNT', '2018-04-04 01:51:57', '2018-04-04 01:51:57');

-- --------------------------------------------------------

--
-- Table structure for table `req_transactions`
--

CREATE TABLE `req_transactions` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `sale_id` int(10) UNSIGNED NOT NULL,
  `customer_id` int(10) UNSIGNED NOT NULL,
  `remarks` text COLLATE utf8mb4_unicode_ci,
  `status` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `description`, `created_at`, `updated_at`) VALUES
(1, 'administrator', 'Administrator', NULL, NULL),
(2, 'radiologist', 'Radiologist', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `role_user`
--

CREATE TABLE `role_user` (
  `id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_user`
--

INSERT INTO `role_user` (`id`, `role_id`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 1, 1, NULL, NULL),
(2, 2, 2, NULL, NULL),
(3, 1, 2, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `id` int(10) UNSIGNED NOT NULL,
  `customer_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(15,2) NOT NULL,
  `discount` decimal(15,2) NOT NULL,
  `total_price` decimal(15,2) NOT NULL,
  `payment_id` int(11) NOT NULL,
  `agency_id` int(10) UNSIGNED NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `days` int(11) NOT NULL DEFAULT '0',
  `transcode` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`id`, `customer_id`, `name`, `quantity`, `unit_price`, `discount`, `total_price`, `payment_id`, `agency_id`, `status`, `created_at`, `updated_at`, `days`, `transcode`) VALUES
(1, 1, 'FULL MED:MMML AGENCY', 1, '3000.00', '550.00', '2450.00', 2, 1, 2, '2018-04-04 01:57:41', '2018-04-04 01:58:54', 29, '20180404638282'),
(2, 2, 'VACCINE', 1, '1200.00', '0.00', '1200.00', 2, 21, 2, '2018-04-05 06:00:42', '2018-04-05 06:01:18', 9, '20180405997888'),
(3, 3, 'VACCINE', 1, '1200.00', '0.00', '1200.00', 2, 2, 2, '2018-04-05 06:09:42', '2018-04-05 06:10:12', 9, '20180405847462'),
(4, 4, 'PRE-MED', 1, '750.00', '0.00', '750.00', 2, 4, 2, '2018-04-05 06:14:05', '2018-04-05 06:14:38', 9, '20180405456792'),
(5, 5, 'PRE-MED', 1, '750.00', '0.00', '750.00', 2, 4, 2, '2018-04-05 06:16:31', '2018-04-05 06:17:08', 9, '20180405788827'),
(6, 6, 'PRE-MED', 1, '750.00', '0.00', '750.00', 2, 4, 2, '2018-04-06 02:20:42', '2018-04-06 02:21:32', 9, '20180406434790'),
(7, 7, 'PRE-MED', 1, '750.00', '0.00', '750.00', 2, 4, 2, '2018-04-06 02:25:28', '2018-04-06 02:26:21', 9, '20180406739449'),
(8, 8, 'PRE-MED', 1, '750.00', '0.00', '750.00', 2, 4, 2, '2018-04-06 02:28:02', '2018-04-06 02:28:26', 9, '20180406331093'),
(9, 9, 'VACCINE', 1, '1200.00', '0.00', '1200.00', 2, 4, 2, '2018-04-06 02:30:01', '2018-04-06 02:30:21', 9, '20180406830427'),
(10, 10, 'PRE-MED', 1, '750.00', '0.00', '750.00', 2, 4, 2, '2018-04-06 02:31:56', '2018-04-06 02:32:35', 9, '20180406793625'),
(11, 11, 'PRE-MED', 1, '750.00', '0.00', '750.00', 2, 4, 2, '2018-04-06 02:34:11', '2018-04-06 02:34:42', 9, '20180406659516'),
(12, 12, 'PHASE 1 DOH PACKAGE', 1, '2200.00', '0.00', '2200.00', 1, 32, 1, '2018-04-06 02:52:54', '2018-04-06 02:53:15', 29, '20180406899529'),
(13, 13, 'PHASE 1 DOH PACKAGE', 1, '2200.00', '0.00', '2200.00', 1, 32, 1, '2018-04-06 02:55:03', '2018-04-06 02:55:19', 29, '20180406820854'),
(14, 14, 'FULL MED:LGH AGENCY', 1, '2200.00', '0.00', '2200.00', 2, 10, 2, '2018-04-06 03:10:19', '2018-04-06 03:10:35', 29, '20180406826098'),
(15, 15, 'FULL MED:LGH AGENCY', 1, '2200.00', '0.00', '2200.00', 2, 10, 2, '2018-04-06 03:11:53', '2018-04-06 03:12:11', 29, '20180406151479'),
(16, 16, 'VACCINE', 1, '1200.00', '0.00', '1200.00', 2, 10, 2, '2018-04-06 03:13:21', '2018-04-06 03:13:56', 9, '20180406563898'),
(17, 17, 'VACCINE', 1, '1200.00', '0.00', '1200.00', 2, 10, 2, '2018-04-06 03:15:11', '2018-04-06 03:15:43', 9, '20180406678406'),
(18, 18, 'FULL MED:LGH AGENCY', 1, '2200.00', '0.00', '2200.00', 2, 10, 2, '2018-04-06 03:17:39', '2018-04-06 03:18:02', 29, '20180406124358'),
(19, 19, 'FULL MED:LGH AGENCY', 1, '2200.00', '0.00', '2200.00', 2, 10, 2, '2018-04-06 03:19:08', '2018-04-06 03:19:25', 29, '20180406363533'),
(20, 20, 'FULL MED:LGH AGENCY', 1, '2200.00', '0.00', '2200.00', 2, 10, 2, '2018-04-06 03:36:23', '2018-04-06 03:36:42', 29, '20180406499854'),
(21, 21, 'FULL MED:KING SOLOMON', 1, '2800.00', '0.00', '2800.00', 2, 8, 2, '2018-04-06 03:37:50', '2018-04-06 03:38:09', 29, '20180406409544'),
(22, 22, 'VACCINE', 1, '1200.00', '0.00', '1200.00', 2, 8, 2, '2018-04-06 05:56:18', '2018-04-06 05:56:49', 9, '20180406584237'),
(23, 23, 'VACCINE', 1, '1200.00', '0.00', '1200.00', 2, 16, 2, '2018-04-06 06:17:41', '2018-04-06 06:18:26', 9, '20180406822389'),
(24, 24, 'VACCINE', 1, '1200.00', '0.00', '1200.00', 2, 23, 2, '2018-04-06 06:20:33', '2018-04-06 06:20:57', 9, '20180406689330'),
(25, 25, 'COMPREHENSIVE TEST', 1, '1500.00', '0.00', '1500.00', 2, 3, 2, '2018-04-07 03:07:12', '2018-04-07 03:07:50', 9, '20180407233224');

-- --------------------------------------------------------

--
-- Table structure for table `sale_discounts`
--

CREATE TABLE `sale_discounts` (
  `id` int(10) UNSIGNED NOT NULL,
  `transcode` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `amount` decimal(11,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `sale_discounts`
--

INSERT INTO `sale_discounts` (`id`, `transcode`, `amount`, `created_at`, `updated_at`) VALUES
(1, '20180405456792', '200.00', '2018-04-05 06:14:28', '2018-04-05 06:14:28'),
(2, '20180405788827', '200.00', '2018-04-05 06:16:51', '2018-04-05 06:17:03'),
(3, '20180406434790', '200.00', '2018-04-06 02:21:20', '2018-04-06 02:21:20'),
(4, '20180406739449', '200.00', '2018-04-06 02:26:15', '2018-04-06 02:26:15'),
(5, '20180406331093', '200.00', '2018-04-06 02:28:21', '2018-04-06 02:28:21'),
(6, '20180406793625', '200.00', '2018-04-06 02:32:29', '2018-04-06 02:32:29'),
(7, '20180406659516', '200.00', '2018-04-06 02:34:36', '2018-04-06 02:34:36'),
(8, '20180406563898', '200.00', '2018-04-06 03:13:50', '2018-04-06 03:13:50'),
(9, '20180406678406', '200.00', '2018-04-06 03:15:37', '2018-04-06 03:15:37'),
(10, '20180406584237', '200.00', '2018-04-06 05:56:44', '2018-04-06 05:56:44'),
(11, '20180406822389', '200.00', '2018-04-06 06:18:03', '2018-04-06 06:18:03'),
(12, '20180406689330', '200.00', '2018-04-06 06:20:51', '2018-04-06 06:20:51'),
(13, '20180407233224', '400.00', '2018-04-07 03:07:43', '2018-04-07 03:07:43');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_xray` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `name`, `category_id`, `created_at`, `updated_at`, `is_xray`) VALUES
(1, 'XRAY: PA', 1, '2018-03-26 08:30:09', '2018-03-26 08:30:09', 1),
(2, 'ALBUMIN', 3, '2018-04-04 05:55:16', '2018-04-04 05:55:16', 0),
(3, 'ALKALINE PHOSPHATASE (ALP)', 3, '2018-04-04 05:56:32', '2018-04-04 05:56:32', 0),
(4, 'BILIRUBIN- DIRECT', 3, '2018-04-04 05:57:05', '2018-04-04 05:57:05', 0),
(5, 'BILIRUBIN- TOTAL', 3, '2018-04-04 05:57:33', '2018-04-04 05:57:33', 0),
(6, 'BILIRUBIN- TOTAL and DIRECT', 3, '2018-04-04 05:58:13', '2018-04-04 05:58:13', 0),
(7, 'BLOOD UREA NITROGEN (BUN)', 3, '2018-04-04 05:58:50', '2018-04-04 05:58:50', 0),
(8, 'CHOLESTEROL- TOTAL', 3, '2018-04-04 06:00:00', '2018-04-04 06:00:00', 0),
(9, 'CREATININE', 3, '2018-04-04 06:00:19', '2018-04-04 06:00:19', 0),
(10, 'FASTING BLOOD SUGAR (FBS/RBS)', 3, '2018-04-04 06:01:03', '2018-04-04 06:01:03', 0),
(11, 'GAMMA GLUTAMYL TRANSFERASE (GGT)', 3, '2018-04-04 06:02:25', '2018-04-04 06:02:25', 0),
(12, 'GLOBULIN', 3, '2018-04-04 06:03:07', '2018-04-04 06:03:07', 0),
(13, 'GLYCOSYLATED HEMOGLOBIN (HBA1C)', 3, '2018-04-04 06:03:49', '2018-04-04 06:03:49', 0),
(14, 'LACTATE DEHYDROGENASE (LDH)', 3, '2018-04-04 06:04:29', '2018-04-04 06:04:29', 0),
(15, 'HDL Cholesterol', 3, '2018-04-04 06:05:09', '2018-04-04 06:05:09', 0),
(16, 'LIPID PROFILE (CHOLE,TRIGLY,HDL,LDL)', 3, '2018-04-04 06:05:48', '2018-04-04 06:05:48', 0),
(17, 'SGOT', 3, '2018-04-04 06:06:11', '2018-04-04 06:06:11', 0),
(18, 'SGPT', 3, '2018-04-04 06:06:45', '2018-04-04 06:06:45', 0),
(19, 'XRAY: ALV', 1, '2018-04-05 02:07:42', '2018-04-05 02:08:35', 0),
(20, 'TOTAL PROTEIN', 3, '2018-04-05 02:09:15', '2018-04-05 02:09:15', 0),
(21, 'TPAG(TOTAL PROTEIN, ALBUMIN, GLOBULIN)', 3, '2018-04-05 02:10:08', '2018-04-05 02:10:08', 0),
(22, 'URIC ACID', 3, '2018-04-05 02:10:33', '2018-04-05 02:10:33', 0),
(23, 'APTT', 4, '2018-04-05 02:10:58', '2018-04-05 02:10:58', 0),
(24, 'APTT WITH MIXING', 4, '2018-04-05 02:11:24', '2018-04-05 02:11:24', 0),
(25, 'BLEEDING TIME', 4, '2018-04-05 02:11:46', '2018-04-05 02:11:46', 0),
(26, 'BLOOD MORPHOLOGY PREPARATION', 4, '2018-04-05 02:12:17', '2018-04-05 02:12:17', 0),
(27, 'BLOOD SMEAR FOR MALARIAL PARASITE', 4, '2018-04-05 02:12:50', '2018-04-05 02:12:50', 0),
(28, 'CLOTTING TIME', 4, '2018-04-05 02:16:35', '2018-04-05 02:16:35', 0),
(29, 'COMPLETE BLOOD COUNT', 4, '2018-04-05 02:16:56', '2018-04-05 02:16:56', 0),
(30, 'COMPLETE BLOOD COUNT(CBC) WITH PLATELET', 4, '2018-04-05 02:17:32', '2018-04-05 02:17:32', 0),
(31, 'DIFFERENTIAL COUNT', 4, '2018-04-05 02:18:09', '2018-04-05 02:18:09', 0),
(32, 'ERYTHROCYTE SEDIMENTATION RATE', 4, '2018-04-05 02:18:55', '2018-04-05 02:18:55', 0),
(33, 'HEMATOCRIT', 4, '2018-04-05 02:19:19', '2018-04-05 02:19:19', 0),
(34, 'HEMOGLOBIN', 4, '2018-04-05 02:19:36', '2018-04-05 02:19:36', 0),
(35, 'PERIPHERAL SMEAR', 4, '2018-04-05 02:20:02', '2018-04-05 02:20:02', 0),
(36, 'PLATELET COUNT', 4, '2018-04-05 02:20:26', '2018-04-05 02:20:26', 0),
(37, 'PROTIME', 4, '2018-04-05 02:20:58', '2018-04-05 02:20:58', 0),
(38, 'RETICULOCYTE COUNT', 4, '2018-04-05 02:21:33', '2018-04-05 02:21:33', 0),
(39, 'Rh TYPING', 4, '2018-04-05 02:22:02', '2018-04-05 02:22:02', 0),
(40, 'WHITE BLOOD  CELL COUNT', 4, '2018-04-05 02:22:55', '2018-04-05 02:22:55', 0),
(41, 'VACCINE', 6, '2018-04-05 02:39:55', '2018-04-05 02:39:55', 0),
(42, 'ANTI-HAV (HAV ANTIBODY)', 2, '2018-04-07 01:29:27', '2018-04-07 01:29:27', 0),
(43, 'ANTI-HAV (raoid test)', 2, '2018-04-07 01:29:55', '2018-04-07 01:29:55', 0),
(44, 'ANTI-HBC Igm', 2, '2018-04-07 01:30:24', '2018-04-07 01:30:24', 0),
(45, 'ANTI-HBc TOTAL', 2, '2018-04-07 01:31:05', '2018-04-07 01:31:05', 0),
(46, 'ANTI-HBe (QUANTITATIVE)', 2, '2018-04-07 01:32:22', '2018-04-07 01:32:22', 0),
(47, 'ANTI-HBs (QUALITATIVE)', 2, '2018-04-07 01:33:39', '2018-04-07 01:33:39', 0),
(48, 'ANTI-HBs (QUANTITATIVE)', 2, '2018-04-07 01:34:21', '2018-04-07 01:34:21', 0),
(49, 'ANTI-HCV (QUALITATIVE)', 2, '2018-04-07 01:34:51', '2018-04-07 01:34:51', 0),
(50, 'ANTI-HCV (QUANTITATIVE)', 2, '2018-04-07 01:35:19', '2018-04-07 01:35:19', 0),
(51, 'HBeAg (QUANTITATIVE)', 2, '2018-04-07 01:36:17', '2018-04-07 01:36:17', 0),
(52, 'HBSAG (QUALITATIVE)', 2, '2018-04-07 01:37:19', '2018-04-07 01:37:19', 0),
(53, 'HBSAG (QUANTITATIVE)', 2, '2018-04-07 01:37:46', '2018-04-07 01:37:46', 0),
(54, 'HIV', 2, '2018-04-07 01:38:10', '2018-04-07 01:38:10', 0),
(55, 'T3', 2, '2018-04-07 01:40:44', '2018-04-07 01:40:44', 0),
(56, 'THYROID PANEL', 2, '2018-04-07 01:43:43', '2018-04-07 01:43:43', 0),
(57, 'T4', 2, '2018-04-07 01:44:40', '2018-04-07 01:44:40', 0),
(58, 'SYPHILIS(RAPID)', 2, '2018-04-07 01:45:06', '2018-04-07 01:55:44', 0),
(59, 'CHEST SPOT VIEW', 1, '2018-04-07 01:56:17', '2018-04-07 01:56:17', 0),
(60, 'SCOLIOSIS SERIES', 1, '2018-04-07 01:56:48', '2018-04-07 01:56:48', 0),
(61, 'THORACO LUMBAR', 1, '2018-04-07 01:57:14', '2018-04-07 01:57:14', 0),
(62, 'APL ARM/THIGH/KNEE/LEG', 1, '2018-04-07 01:57:56', '2018-04-07 01:57:56', 0),
(63, 'MANDIBLE(PA,L AND R OBLIQUE)', 1, '2018-04-07 01:58:49', '2018-04-07 01:58:49', 0),
(64, 'PELVIS', 1, '2018-04-07 01:59:04', '2018-04-07 01:59:04', 0),
(65, 'ABDOMEN (AP/LATERAL)', 1, '2018-04-07 01:59:33', '2018-04-07 01:59:33', 0),
(66, 'TBC', 1, '2018-04-07 01:59:53', '2018-04-07 01:59:53', 0),
(67, 'BONE AGE TEST', 1, '2018-04-07 02:00:16', '2018-04-07 02:00:16', 0),
(68, 'SKULL SERIES (PA,L AND R OBLIQUE)', 1, '2018-04-07 02:00:53', '2018-04-07 02:00:53', 0),
(69, 'NIPPLE MARKER', 1, '2018-04-07 02:01:09', '2018-04-07 02:01:09', 0),
(70, 'THORACIC', 1, '2018-04-07 02:01:28', '2018-04-07 02:01:28', 0),
(71, 'LUMBO- SACRAL', 1, '2018-04-07 02:02:04', '2018-04-07 02:02:04', 0),
(72, 'ECG', 8, '2018-04-07 02:05:00', '2018-04-07 02:05:00', 0),
(73, 'USD WHOLE ABDOMEN', 7, '2018-04-07 02:06:17', '2018-04-07 02:06:17', 0),
(74, 'USD THYROID/NECK', 7, '2018-04-07 02:06:48', '2018-04-07 02:06:48', 0),
(75, 'USD LIVER', 7, '2018-04-07 02:07:05', '2018-04-07 02:07:05', 0),
(76, 'USD TRANSVAGINAL', 7, '2018-04-07 02:07:25', '2018-04-07 02:07:25', 0),
(77, 'USD PANCREAS', 7, '2018-04-07 02:07:52', '2018-04-07 02:07:52', 0),
(78, 'USD SMALL PARTS', 7, '2018-04-07 02:08:09', '2018-04-07 02:08:09', 0),
(79, 'USD PELVIS (PREGNANCY EVAL)', 7, '2018-04-07 02:08:43', '2018-04-07 02:08:43', 0),
(80, 'USD KIDNEY', 7, '2018-04-07 02:09:04', '2018-04-07 02:09:04', 0),
(81, 'USD THORAX', 7, '2018-04-07 02:09:45', '2018-04-07 02:09:45', 0),
(82, 'USD KUB+', 7, '2018-04-07 02:10:10', '2018-04-07 02:10:10', 0),
(83, 'USD SPLEEN', 7, '2018-04-07 02:10:32', '2018-04-07 02:10:32', 0),
(84, 'URINE CONTAINER', 9, '2018-04-07 02:18:04', '2018-04-07 02:18:04', 0),
(85, 'STOOL CONTAINER', 9, '2018-04-07 02:18:25', '2018-04-07 02:18:25', 0),
(86, 'PREGNANCY TEST', 2, '2018-04-07 03:16:08', '2018-04-07 03:16:08', 0);

-- --------------------------------------------------------

--
-- Table structure for table `service_items`
--

CREATE TABLE `service_items` (
  `id` int(10) UNSIGNED NOT NULL,
  `service_id` int(10) UNSIGNED NOT NULL,
  `service` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cov` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `group` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nv` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `remarks` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `service_items`
--

INSERT INTO `service_items` (`id`, `service_id`, `service`, `cov`, `group`, `nv`, `created_at`, `updated_at`, `remarks`) VALUES
(1, 19, NULL, NULL, NULL, NULL, '2018-04-05 02:08:14', '2018-04-05 02:08:14', NULL),
(2, 39, NULL, NULL, NULL, NULL, '2018-04-05 02:22:24', '2018-04-05 02:22:24', NULL),
(3, 58, NULL, NULL, NULL, NULL, '2018-04-07 01:55:44', '2018-04-07 01:55:44', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `service_prices`
--

CREATE TABLE `service_prices` (
  `id` int(11) NOT NULL,
  `service_id` int(10) UNSIGNED NOT NULL,
  `price` decimal(15,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `service_prices`
--

INSERT INTO `service_prices` (`id`, `service_id`, `price`, `created_at`, `updated_at`) VALUES
(1, 1, '170.00', '2018-03-26 08:30:09', '2018-03-26 08:30:09'),
(2, 2, '195.00', '2018-04-04 05:55:16', '2018-04-04 05:55:16'),
(3, 3, '240.00', '2018-04-04 05:56:32', '2018-04-04 05:56:32'),
(4, 3, '210.00', '2018-04-04 05:56:32', '2018-04-04 05:56:32'),
(5, 4, '170.00', '2018-04-04 05:57:05', '2018-04-04 05:57:05'),
(6, 5, '170.00', '2018-04-04 05:57:34', '2018-04-04 05:57:34'),
(7, 6, '295.00', '2018-04-04 05:58:13', '2018-04-04 05:58:13'),
(8, 7, '195.00', '2018-04-04 05:58:50', '2018-04-04 05:58:50'),
(9, 7, '165.00', '2018-04-04 05:58:50', '2018-04-04 05:58:50'),
(10, 8, '190.00', '2018-04-04 06:00:00', '2018-04-04 06:00:00'),
(11, 9, '165.00', '2018-04-04 06:00:19', '2018-04-04 06:00:19'),
(12, 9, '140.00', '2018-04-04 06:00:20', '2018-04-04 06:00:20'),
(13, 10, '90.00', '2018-04-04 06:01:03', '2018-04-04 06:01:03'),
(14, 11, '450.00', '2018-04-04 06:02:25', '2018-04-04 06:02:25'),
(15, 11, '415.00', '2018-04-04 06:02:25', '2018-04-04 06:02:25'),
(16, 12, '350.00', '2018-04-04 06:03:07', '2018-04-04 06:03:07'),
(17, 12, '335.00', '2018-04-04 06:03:07', '2018-04-04 06:03:07'),
(18, 13, '850.00', '2018-04-04 06:03:49', '2018-04-04 06:03:49'),
(19, 14, '380.00', '2018-04-04 06:04:29', '2018-04-04 06:04:29'),
(20, 14, '320.00', '2018-04-04 06:04:29', '2018-04-04 06:04:29'),
(21, 15, '435.00', '2018-04-04 06:05:09', '2018-04-04 06:05:09'),
(22, 15, '200.00', '2018-04-04 06:05:09', '2018-04-04 06:05:09'),
(23, 16, '480.00', '2018-04-04 06:05:49', '2018-04-04 06:05:49'),
(24, 16, '450.00', '2018-04-04 06:05:49', '2018-04-04 06:05:49'),
(25, 17, '190.00', '2018-04-04 06:06:11', '2018-04-04 06:06:11'),
(26, 18, '190.00', '2018-04-04 06:06:45', '2018-04-04 06:06:45'),
(31, 19, '220.00', '2018-04-05 02:08:35', '2018-04-05 02:08:35'),
(32, 19, '170.00', '2018-04-05 02:08:35', '2018-04-05 02:08:35'),
(33, 20, '235.00', '2018-04-05 02:09:15', '2018-04-05 02:09:15'),
(34, 20, '190.00', '2018-04-05 02:09:15', '2018-04-05 02:09:15'),
(35, 21, '405.00', '2018-04-05 02:10:08', '2018-04-05 02:10:08'),
(36, 21, '350.00', '2018-04-05 02:10:08', '2018-04-05 02:10:08'),
(37, 22, '145.00', '2018-04-05 02:10:33', '2018-04-05 02:10:33'),
(38, 23, '410.00', '2018-04-05 02:10:59', '2018-04-05 02:10:59'),
(39, 23, '355.00', '2018-04-05 02:10:59', '2018-04-05 02:10:59'),
(40, 24, '640.00', '2018-04-05 02:11:24', '2018-04-05 02:11:24'),
(41, 25, '40.00', '2018-04-05 02:11:46', '2018-04-05 02:11:46'),
(42, 26, '95.00', '2018-04-05 02:12:17', '2018-04-05 02:12:17'),
(43, 27, '80.00', '2018-04-05 02:12:50', '2018-04-05 02:12:50'),
(44, 28, '40.00', '2018-04-05 02:16:35', '2018-04-05 02:16:35'),
(45, 29, '150.00', '2018-04-05 02:16:56', '2018-04-05 02:16:56'),
(46, 30, '150.00', '2018-04-05 02:17:32', '2018-04-05 02:17:32'),
(47, 31, '90.00', '2018-04-05 02:18:09', '2018-04-05 02:18:09'),
(48, 32, '115.00', '2018-04-05 02:18:55', '2018-04-05 02:18:55'),
(49, 33, '50.00', '2018-04-05 02:19:19', '2018-04-05 02:19:19'),
(50, 34, '110.00', '2018-04-05 02:19:36', '2018-04-05 02:19:36'),
(51, 35, '350.00', '2018-04-05 02:20:02', '2018-04-05 02:20:02'),
(52, 35, '290.00', '2018-04-05 02:20:02', '2018-04-05 02:20:02'),
(53, 36, '95.00', '2018-04-05 02:20:26', '2018-04-05 02:20:26'),
(54, 37, '355.00', '2018-04-05 02:20:58', '2018-04-05 02:20:58'),
(55, 37, '200.00', '2018-04-05 02:20:58', '2018-04-05 02:20:58'),
(56, 38, '115.00', '2018-04-05 02:21:33', '2018-04-05 02:21:33'),
(58, 39, '45.00', '2018-04-05 02:22:24', '2018-04-05 02:22:24'),
(59, 40, '90.00', '2018-04-05 02:22:55', '2018-04-05 02:22:55'),
(60, 41, '1200.00', '2018-04-05 02:39:55', '2018-04-05 02:39:55'),
(61, 41, '1100.00', '2018-04-05 02:39:55', '2018-04-05 02:39:55'),
(62, 41, '1000.00', '2018-04-05 02:39:55', '2018-04-05 02:39:55'),
(63, 42, '550.00', '2018-04-07 01:29:27', '2018-04-07 01:29:27'),
(64, 42, '450.00', '2018-04-07 01:29:27', '2018-04-07 01:29:27'),
(65, 42, '350.00', '2018-04-07 01:29:27', '2018-04-07 01:29:27'),
(66, 43, '230.00', '2018-04-07 01:29:55', '2018-04-07 01:29:55'),
(67, 44, '650.00', '2018-04-07 01:30:24', '2018-04-07 01:30:24'),
(68, 44, '550.00', '2018-04-07 01:30:24', '2018-04-07 01:30:24'),
(69, 45, '550.00', '2018-04-07 01:31:05', '2018-04-07 01:31:05'),
(70, 45, '300.00', '2018-04-07 01:31:05', '2018-04-07 01:31:05'),
(71, 46, '650.00', '2018-04-07 01:32:22', '2018-04-07 01:32:22'),
(72, 46, '500.00', '2018-04-07 01:32:22', '2018-04-07 01:32:22'),
(73, 47, '230.00', '2018-04-07 01:33:39', '2018-04-07 01:33:39'),
(74, 47, '160.00', '2018-04-07 01:33:39', '2018-04-07 01:33:39'),
(75, 48, '410.00', '2018-04-07 01:34:21', '2018-04-07 01:34:21'),
(76, 48, '280.00', '2018-04-07 01:34:21', '2018-04-07 01:34:21'),
(77, 49, '300.00', '2018-04-07 01:34:51', '2018-04-07 01:34:51'),
(78, 49, '290.00', '2018-04-07 01:34:51', '2018-04-07 01:34:51'),
(79, 50, '500.00', '2018-04-07 01:35:19', '2018-04-07 01:35:19'),
(80, 50, '450.00', '2018-04-07 01:35:20', '2018-04-07 01:35:20'),
(81, 51, '550.00', '2018-04-07 01:36:17', '2018-04-07 01:36:17'),
(82, 51, '450.00', '2018-04-07 01:36:17', '2018-04-07 01:36:17'),
(83, 52, '170.00', '2018-04-07 01:37:19', '2018-04-07 01:37:19'),
(84, 52, '150.00', '2018-04-07 01:37:19', '2018-04-07 01:37:19'),
(85, 53, '280.00', '2018-04-07 01:37:46', '2018-04-07 01:37:46'),
(86, 53, '250.00', '2018-04-07 01:37:46', '2018-04-07 01:37:46'),
(87, 54, '600.00', '2018-04-07 01:38:10', '2018-04-07 01:38:10'),
(88, 54, '500.00', '2018-04-07 01:38:10', '2018-04-07 01:38:10'),
(89, 55, '410.00', '2018-04-07 01:40:44', '2018-04-07 01:40:44'),
(90, 55, '280.00', '2018-04-07 01:40:44', '2018-04-07 01:40:44'),
(91, 55, '250.00', '2018-04-07 01:40:45', '2018-04-07 01:40:45'),
(92, 56, '999.00', '2018-04-07 01:43:43', '2018-04-07 01:43:43'),
(93, 56, '810.00', '2018-04-07 01:43:43', '2018-04-07 01:43:43'),
(94, 56, '750.00', '2018-04-07 01:43:43', '2018-04-07 01:43:43'),
(95, 57, '410.00', '2018-04-07 01:44:40', '2018-04-07 01:44:40'),
(96, 57, '280.00', '2018-04-07 01:44:41', '2018-04-07 01:44:41'),
(97, 57, '250.00', '2018-04-07 01:44:41', '2018-04-07 01:44:41'),
(100, 58, '280.00', '2018-04-07 01:55:44', '2018-04-07 01:55:44'),
(101, 58, '180.00', '2018-04-07 01:55:44', '2018-04-07 01:55:44'),
(102, 59, '220.00', '2018-04-07 01:56:17', '2018-04-07 01:56:17'),
(103, 59, '170.00', '2018-04-07 01:56:17', '2018-04-07 01:56:17'),
(104, 60, '1150.00', '2018-04-07 01:56:48', '2018-04-07 01:56:48'),
(105, 61, '650.00', '2018-04-07 01:57:14', '2018-04-07 01:57:14'),
(106, 62, '320.00', '2018-04-07 01:57:57', '2018-04-07 01:57:57'),
(107, 63, '400.00', '2018-04-07 01:58:49', '2018-04-07 01:58:49'),
(108, 64, '350.00', '2018-04-07 01:59:04', '2018-04-07 01:59:04'),
(109, 65, '400.00', '2018-04-07 01:59:33', '2018-04-07 01:59:33'),
(110, 66, '250.00', '2018-04-07 01:59:53', '2018-04-07 01:59:53'),
(111, 67, '250.00', '2018-04-07 02:00:16', '2018-04-07 02:00:16'),
(112, 68, '400.00', '2018-04-07 02:00:53', '2018-04-07 02:00:53'),
(113, 69, '170.00', '2018-04-07 02:01:09', '2018-04-07 02:01:09'),
(114, 70, '350.00', '2018-04-07 02:01:28', '2018-04-07 02:01:28'),
(115, 71, '460.00', '2018-04-07 02:02:04', '2018-04-07 02:02:04'),
(116, 72, '250.00', '2018-04-07 02:05:00', '2018-04-07 02:05:00'),
(117, 72, '220.00', '2018-04-07 02:05:00', '2018-04-07 02:05:00'),
(118, 73, '1200.00', '2018-04-07 02:06:17', '2018-04-07 02:06:17'),
(119, 74, '800.00', '2018-04-07 02:06:48', '2018-04-07 02:06:48'),
(120, 75, '550.00', '2018-04-07 02:07:05', '2018-04-07 02:07:05'),
(121, 76, '800.00', '2018-04-07 02:07:25', '2018-04-07 02:07:25'),
(122, 77, '550.00', '2018-04-07 02:07:52', '2018-04-07 02:07:52'),
(123, 78, '550.00', '2018-04-07 02:08:09', '2018-04-07 02:08:09'),
(124, 79, '600.00', '2018-04-07 02:08:43', '2018-04-07 02:08:43'),
(125, 80, '750.00', '2018-04-07 02:09:04', '2018-04-07 02:09:04'),
(126, 81, '600.00', '2018-04-07 02:09:45', '2018-04-07 02:09:45'),
(127, 82, '800.00', '2018-04-07 02:10:11', '2018-04-07 02:10:11'),
(128, 83, '550.00', '2018-04-07 02:10:32', '2018-04-07 02:10:32'),
(129, 84, '15.00', '2018-04-07 02:18:04', '2018-04-07 02:18:04'),
(130, 85, '10.00', '2018-04-07 02:18:25', '2018-04-07 02:18:25'),
(131, 86, '170.00', '2018-04-07 03:16:09', '2018-04-07 03:16:09');

-- --------------------------------------------------------

--
-- Table structure for table `service_supplies`
--

CREATE TABLE `service_supplies` (
  `id` int(10) UNSIGNED NOT NULL,
  `supply_id` int(10) UNSIGNED NOT NULL,
  `service_id` int(10) UNSIGNED NOT NULL,
  `qty` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(10) UNSIGNED NOT NULL,
  `set_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `set_name`, `name`, `created_at`, `updated_at`) VALUES
(1, 'fingerprint', '/hyatt/timekeeper/timekeeper.exe', NULL, NULL),
(2, 'vaccine_nurse', 'CHARLENE MAE A. RODRIGO, RN', NULL, '2018-03-05 08:59:43'),
(3, 'vaccine_license', '0857554', NULL, '2018-03-05 08:59:43'),
(5, '_token', 'iKj6vRABtReiD0dMlZuy2pxiGTzJM1zqNdWIOaQm', '2018-03-05 08:59:42', '2018-03-05 08:59:42'),
(6, 'vaccine_signature', NULL, '2018-03-05 09:01:10', '2018-03-05 09:01:10');

-- --------------------------------------------------------

--
-- Table structure for table `supplies`
--

CREATE TABLE `supplies` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `min_qty` decimal(11,1) NOT NULL DEFAULT '0.0',
  `test_per_unit` int(11) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `unit` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remarks` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `transmittals`
--

CREATE TABLE `transmittals` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `customer_id` int(10) UNSIGNED NOT NULL,
  `agency_id` int(10) UNSIGNED NOT NULL,
  `status_id` int(10) UNSIGNED NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remarks` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `encode_date` date DEFAULT NULL,
  `expiry_date` date NOT NULL,
  `exp_display` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `fullName` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `license_no` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `position` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`, `fullName`, `license_no`, `position`) VALUES
(1, 'admin', 'admin@gmail.com', '$2y$10$x0zXx0quMEZ2mHRe/7rdGelpz83ge9pQ1YQLkEkZok68JQgpeOSF.', '90LkKE9lZB5goK3oLWeaJPNi7RGbzzFZxqU2Kg4ahynjAWM7eAKv2pnngAZ8', '2018-02-06 09:22:49', '2018-02-06 09:22:49', 'Administrator', NULL, 'Manager'),
(2, 'Jaybee', 'jaybee@gmail.com', '$2y$10$1xhCV5OloqeRlq53EcEKDe5TxMqzj0D0FYUo1V3mIXywSCcgBJ8HS', 'JX7Nmnu03DelZ8dBroQDqlhL1ouB9lRwfMrR1d6Z6X0GolYF1LqiDN3go9EN', '2018-02-06 10:18:43', '2018-02-06 10:18:43', 'Michael P. Maceda, MD, FPCR', NULL, 'Radiologist');

-- --------------------------------------------------------

--
-- Table structure for table `vaccines`
--

CREATE TABLE `vaccines` (
  `id` int(10) UNSIGNED NOT NULL,
  `customer_id` int(10) UNSIGNED NOT NULL,
  `brand_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lot_no` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `expiry_date` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_given` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `nurse_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `lic_no` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `current_age` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `xray_results`
--

CREATE TABLE `xray_results` (
  `id` int(10) UNSIGNED NOT NULL,
  `customer_id` int(10) UNSIGNED NOT NULL,
  `lab_result_id` int(10) UNSIGNED NOT NULL,
  `file_no` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date` date DEFAULT NULL,
  `clinical_data` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `remarks` text COLLATE utf8_unicode_ci,
  `impression` text COLLATE utf8_unicode_ci,
  `is_done` int(11) NOT NULL DEFAULT '0',
  `prepared_id` int(10) UNSIGNED NOT NULL,
  `radiologist_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `agencies`
--
ALTER TABLE `agencies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `agency_contacts`
--
ALTER TABLE `agency_contacts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `agency_contacts_agency_id_foreign` (`agency_id`);

--
-- Indexes for table `agency_customer`
--
ALTER TABLE `agency_customer`
  ADD PRIMARY KEY (`id`),
  ADD KEY `agency_customer_customer_id_foreign` (`customer_id`),
  ADD KEY `agency_customer_agency_id_foreign` (`agency_id`);

--
-- Indexes for table `agency_emails`
--
ALTER TABLE `agency_emails`
  ADD PRIMARY KEY (`id`),
  ADD KEY `agency_emails_agency_id_foreign` (`agency_id`);

--
-- Indexes for table `agency_pricings`
--
ALTER TABLE `agency_pricings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `agency_pricings_package_id_foreign` (`package_id`),
  ADD KEY `agency_pricings_agency_id_foreign` (`agency_id`),
  ADD KEY `agency_pricings_pricing_type_id_foreign` (`pricing_type_id`);

--
-- Indexes for table `associations`
--
ALTER TABLE `associations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`id`),
  ADD KEY `countries_association_id_foreign` (`association_id`);

--
-- Indexes for table `country_customer`
--
ALTER TABLE `country_customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fingerprints`
--
ALTER TABLE `fingerprints`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fingerprints_customer_id_foreign` (`customer_id`);

--
-- Indexes for table `inventory_lab_result_items`
--
ALTER TABLE `inventory_lab_result_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `inventory_lab_result_items_customer_id_foreign` (`customer_id`),
  ADD KEY `inventory_lab_result_items_sale_id_foreign` (`sale_id`),
  ADD KEY `inventory_lab_result_items_lab_result_id_foreign` (`lab_result_id`),
  ADD KEY `inventory_lab_result_items_supply_id_foreign` (`supply_id`);

--
-- Indexes for table `inventory_receives`
--
ALTER TABLE `inventory_receives`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inventory_receive_items`
--
ALTER TABLE `inventory_receive_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `inventory_receive_items_inventory_receive_id_foreign` (`inventory_receive_id`),
  ADD KEY `inventory_receive_items_supply_id_foreign` (`supply_id`);

--
-- Indexes for table `inventory_returns`
--
ALTER TABLE `inventory_returns`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inventory_return_items`
--
ALTER TABLE `inventory_return_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `inventory_return_items_inventory_return_id_foreign` (`inventory_return_id`),
  ADD KEY `inventory_return_items_supply_id_foreign` (`supply_id`);

--
-- Indexes for table `lab_results`
--
ALTER TABLE `lab_results`
  ADD PRIMARY KEY (`id`),
  ADD KEY `lab_results_service_id_foreign` (`service_id`),
  ADD KEY `lab_results_sale_id_foreign` (`sale_id`),
  ADD KEY `lab_results_customer_id_foreign` (`customer_id`);

--
-- Indexes for table `lab_result_items`
--
ALTER TABLE `lab_result_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `lab_result_items_lab_result_id_foreign` (`lab_result_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `packages`
--
ALTER TABLE `packages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `package_service`
--
ALTER TABLE `package_service`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `payments_sale_id_foreign` (`sale_id`),
  ADD KEY `payments_customer_id_foreign` (`customer_id`);

--
-- Indexes for table `pricing_types`
--
ALTER TABLE `pricing_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `req_transactions`
--
ALTER TABLE `req_transactions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `req_transactions_sale_id_foreign` (`sale_id`),
  ADD KEY `req_transactions_customer_id_foreign` (`customer_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `role_user`
--
ALTER TABLE `role_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sales_customer_id_foreign` (`customer_id`),
  ADD KEY `sales_agency_id_foreign` (`agency_id`);

--
-- Indexes for table `sale_discounts`
--
ALTER TABLE `sale_discounts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`),
  ADD KEY `services_category_id_foreign` (`category_id`);

--
-- Indexes for table `service_items`
--
ALTER TABLE `service_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `service_items_service_id_foreign` (`service_id`);

--
-- Indexes for table `service_prices`
--
ALTER TABLE `service_prices`
  ADD PRIMARY KEY (`id`),
  ADD KEY `service_prices_service_id_foreign` (`service_id`);

--
-- Indexes for table `service_supplies`
--
ALTER TABLE `service_supplies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `settings_set_name_unique` (`set_name`);

--
-- Indexes for table `supplies`
--
ALTER TABLE `supplies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transmittals`
--
ALTER TABLE `transmittals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `transmittals_user_id_foreign` (`user_id`),
  ADD KEY `transmittals_customer_id_foreign` (`customer_id`),
  ADD KEY `transmittals_agency_id_foreign` (`agency_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `vaccines`
--
ALTER TABLE `vaccines`
  ADD PRIMARY KEY (`id`),
  ADD KEY `vaccines_customer_id_foreign` (`customer_id`);

--
-- Indexes for table `xray_results`
--
ALTER TABLE `xray_results`
  ADD PRIMARY KEY (`id`),
  ADD KEY `xray_results_customer_id_foreign` (`customer_id`),
  ADD KEY `xray_results_lab_result_id_foreign` (`lab_result_id`),
  ADD KEY `xray_results_prepared_id_foreign` (`prepared_id`),
  ADD KEY `xray_results_radiologist_id_foreign` (`radiologist_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `agencies`
--
ALTER TABLE `agencies`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT for table `agency_contacts`
--
ALTER TABLE `agency_contacts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `agency_customer`
--
ALTER TABLE `agency_customer`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `agency_emails`
--
ALTER TABLE `agency_emails`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;
--
-- AUTO_INCREMENT for table `agency_pricings`
--
ALTER TABLE `agency_pricings`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `associations`
--
ALTER TABLE `associations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `countries`
--
ALTER TABLE `countries`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `country_customer`
--
ALTER TABLE `country_customer`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `fingerprints`
--
ALTER TABLE `fingerprints`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `inventory_lab_result_items`
--
ALTER TABLE `inventory_lab_result_items`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `inventory_receives`
--
ALTER TABLE `inventory_receives`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `inventory_receive_items`
--
ALTER TABLE `inventory_receive_items`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `inventory_returns`
--
ALTER TABLE `inventory_returns`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `inventory_return_items`
--
ALTER TABLE `inventory_return_items`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `lab_results`
--
ALTER TABLE `lab_results`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `lab_result_items`
--
ALTER TABLE `lab_result_items`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;
--
-- AUTO_INCREMENT for table `packages`
--
ALTER TABLE `packages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;
--
-- AUTO_INCREMENT for table `package_service`
--
ALTER TABLE `package_service`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;
--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `pricing_types`
--
ALTER TABLE `pricing_types`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `req_transactions`
--
ALTER TABLE `req_transactions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `role_user`
--
ALTER TABLE `role_user`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `sale_discounts`
--
ALTER TABLE `sale_discounts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=87;
--
-- AUTO_INCREMENT for table `service_items`
--
ALTER TABLE `service_items`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `service_prices`
--
ALTER TABLE `service_prices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=132;
--
-- AUTO_INCREMENT for table `service_supplies`
--
ALTER TABLE `service_supplies`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `supplies`
--
ALTER TABLE `supplies`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `transmittals`
--
ALTER TABLE `transmittals`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `vaccines`
--
ALTER TABLE `vaccines`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `xray_results`
--
ALTER TABLE `xray_results`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `agency_contacts`
--
ALTER TABLE `agency_contacts`
  ADD CONSTRAINT `agency_contacts_agency_id_foreign` FOREIGN KEY (`agency_id`) REFERENCES `agencies` (`id`);

--
-- Constraints for table `agency_customer`
--
ALTER TABLE `agency_customer`
  ADD CONSTRAINT `agency_customer_agency_id_foreign` FOREIGN KEY (`agency_id`) REFERENCES `agencies` (`id`),
  ADD CONSTRAINT `agency_customer_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`);

--
-- Constraints for table `agency_emails`
--
ALTER TABLE `agency_emails`
  ADD CONSTRAINT `agency_emails_agency_id_foreign` FOREIGN KEY (`agency_id`) REFERENCES `agencies` (`id`);

--
-- Constraints for table `agency_pricings`
--
ALTER TABLE `agency_pricings`
  ADD CONSTRAINT `agency_pricings_agency_id_foreign` FOREIGN KEY (`agency_id`) REFERENCES `agencies` (`id`),
  ADD CONSTRAINT `agency_pricings_package_id_foreign` FOREIGN KEY (`package_id`) REFERENCES `packages` (`id`),
  ADD CONSTRAINT `agency_pricings_pricing_type_id_foreign` FOREIGN KEY (`pricing_type_id`) REFERENCES `pricing_types` (`id`);

--
-- Constraints for table `countries`
--
ALTER TABLE `countries`
  ADD CONSTRAINT `countries_association_id_foreign` FOREIGN KEY (`association_id`) REFERENCES `associations` (`id`);

--
-- Constraints for table `fingerprints`
--
ALTER TABLE `fingerprints`
  ADD CONSTRAINT `fingerprints_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`);

--
-- Constraints for table `inventory_lab_result_items`
--
ALTER TABLE `inventory_lab_result_items`
  ADD CONSTRAINT `inventory_lab_result_items_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`),
  ADD CONSTRAINT `inventory_lab_result_items_lab_result_id_foreign` FOREIGN KEY (`lab_result_id`) REFERENCES `lab_results` (`id`),
  ADD CONSTRAINT `inventory_lab_result_items_sale_id_foreign` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`),
  ADD CONSTRAINT `inventory_lab_result_items_supply_id_foreign` FOREIGN KEY (`supply_id`) REFERENCES `supplies` (`id`);

--
-- Constraints for table `inventory_receive_items`
--
ALTER TABLE `inventory_receive_items`
  ADD CONSTRAINT `inventory_receive_items_inventory_receive_id_foreign` FOREIGN KEY (`inventory_receive_id`) REFERENCES `inventory_receives` (`id`),
  ADD CONSTRAINT `inventory_receive_items_supply_id_foreign` FOREIGN KEY (`supply_id`) REFERENCES `supplies` (`id`);

--
-- Constraints for table `inventory_return_items`
--
ALTER TABLE `inventory_return_items`
  ADD CONSTRAINT `inventory_return_items_inventory_return_id_foreign` FOREIGN KEY (`inventory_return_id`) REFERENCES `inventory_returns` (`id`),
  ADD CONSTRAINT `inventory_return_items_supply_id_foreign` FOREIGN KEY (`supply_id`) REFERENCES `supplies` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
